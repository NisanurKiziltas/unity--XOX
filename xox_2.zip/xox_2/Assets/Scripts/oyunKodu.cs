using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class oyunKodu : MonoBehaviour
{
    public Camera camera;
  
    public Material red;
    public Material yellow;

    private int[] squares;
    private Vector3[] xSignPositions;
    private Vector3[] oSignPositions;
    private int playerOrder; // 1 -> x,  2 -> 0
    private int xOrder; // x şekillerinin sırası
    private int oOrder; // o şekillerinin sırası
    private int moveCount;
    private GameObject square;
    
   //public Button PlayAgainButton;
    public Text message;
    public bool gameEnd;

    void Start()
    {
      // message.enabled = false;        
     // PlayAgainButton.enabled = false;
        gameEnd = false;
        
        xSignPositions = new Vector3[5];
        oSignPositions = new Vector3[5];
        squares= new int[]{0,0,0,0,0,0,0,0,0};
        playerOrder = 1;
        xOrder = 1;
        oOrder = 1;
        moveCount = 0;
    }

	private void clear()
	{// 0 -> boş, 1 -> x, 2 -> o
	 squares= new int[]{0,0,0,0,0,0,0,0,0};
        playerOrder = 1;
        xOrder = 1;
        oOrder = 1;
        moveCount = 0;
        
        for(int i=0; i<5; i++){
             
            Rigidbody rbx = GameObject.Find("x"+(i+1)).GetComponent<Rigidbody>();
            rbx.MovePosition(xSignPositions[i]);
             
            Rigidbody rbo = GameObject.Find("o"+(i+1)).GetComponent<Rigidbody>();
            rbo.MovePosition(oSignPositions[i]);
        }
	}

    int counter = 0;
    int q0=0;           int w0=0;  
    int q1=0;           int w1=0;
    int q2=0;           int w2=0;
    int q3=0;           int w3=0;
    int q4=0;           int w4=0;
    int q5=0;           int w5=0;
    int q6=0;           int w6=0;
    int q7=0;           int w7=0;
    int q8=0;           int w8=0;
    
  
 
    void Update()
    {
       int squareNumber =  getClickedSquare();
       if ( squareNumber >=0 && squareNumber < 9)
       {
           if(isSquareEmpty(squareNumber)){
             
               Renderer  renderer =  getSquareRenderer(squareNumber);
               renderer.material = yellow;

                Vector3 yer = KareKonum(squareNumber);
               if (playerOrder == 1 && !gameEnd)
                
               {
                   
                    
                    Rigidbody rbx = GameObject.Find("x" + (xOrder)).GetComponent<Rigidbody>();
                                                       
                    rbx.MovePosition(yer);

                    if (yer == new Vector3(-2, 1, -2)) q0 = 1;
                    if (yer == new Vector3(-2, 1,  0)) q1 = 1;
                    if (yer == new Vector3(-2, 1, +2)) q2 = 1;
                    if (yer == new Vector3( 0, 1, -2)) q3 = 1;
                    if (yer == new Vector3( 0, 1,  0)) q4 = 1;
                    if (yer == new Vector3( 0, 1, +2)) q5 = 1;
                    if (yer == new Vector3(+2, 1, -2)) q6 = 1;
                    if (yer == new Vector3(+2, 1,  0)) q7 = 1;
                    if (yer == new Vector3(+2, 1, +2)) q8 = 1;
                    if ((q0 == 1 && q1 == 1 && q2 == 1) || (q3 == 1 && q4 == 1 && q5 == 1) ||(q6 == 1 && q7 ==1&& q8 == 1) ||
                        (q0 == 1 && q3 == 1&& q6 == 1) || (q1 == 1&& q4 == 1&& q7 == 1) || (q2 == 1 && q5 == 1 && q8 == 1) ||
                        (q0 == 1&& q4 == 1 && q8 == 1) ||(q2 == 1 && q4 == 1 && q6 == 1))

                    {
                        Debug.Log(" X KAZANDI");
                        //PlayAgainButton.enabled = true;
                        //message.enabled = true;
                        //message.text = "winer is x";
                        gameEnd = true;restart();
                       
                        
                    }

                    
                    xOrder++;  
                moveCount++;
                squares[squareNumber] = 1;
                playerOrder = 2;
               }
               else if(playerOrder == 2)
               {
                   
                    

                    Rigidbody rbo = GameObject.Find("o" + (oOrder)).GetComponent<Rigidbody>();

                    rbo.MovePosition(yer);


                    if (yer == new Vector3(-2, 1, -2)) w0 = 1;
                    if (yer == new Vector3(-2, 1, 0)) w1 = 1;
                    if (yer == new Vector3(-2, 1, +2)) w2 = 1;
                    if (yer == new Vector3(0, 1, -2)) w3 = 1;
                    if (yer == new Vector3(0, 1, 0)) w4 = 1;
                    if (yer == new Vector3(0, 1, +2)) w5 = 1;
                    if (yer == new Vector3(+2, 1, -2)) w6 = 1;
                    if (yer == new Vector3(+2, 1, 0)) w7 = 1;
                    if (yer == new Vector3(+2, 1, +2)) w8 = 1;
                   
                    if ((w0 == 1 && w1 == 1&& w2 == 1) || (w3 == 1&& w4 == 1 && w5 == 1) || (w6 == 1 && w7 == 1 && w8 == 1) ||
                        (w0 == 1 && w3 == 1 && w6 == 1) ||(w1 == 1 && w4 == 1 && w7 ==1) ||(w2 == 1 && w5 == 1 && w8 == 1) ||
                         (w0 == 1 && w4 == 1 && w8 == 1) || (w2 == 1 && w4 == 1 && w6 == 1))
                        
                           
                    {
                       Debug.Log(" O KAZANDI ");
                       //PlayAgainButton.enabled = true;
                        //message.enabled = true;
                        //message.text = "winer is o";
                        gameEnd = true;restart();
                       
                    }
                    
                 
                    oOrder++;  
                moveCount++;
                squares[squareNumber] = 2;
                playerOrder = 1;
               }
 
 
 
 
             switch(checkBoardState()){
                 //case 0: Debug.Log("Oyun sırası "+playerOrder+". oyuncuda."); break;
                 case 1: Debug.Log("Oyunu "+playerOrder+". oyuncu kazandı."); clear(); break;
                 case 2: Debug.Log("Oyunu "+playerOrder+". oyuncu kazandı."); clear(); break;
                 case 3: Debug.Log("Oyunu berabere bitti."); clear(); break;
             }

           }else{

               Renderer  renderer =  getSquareRenderer(squareNumber);
               renderer.material = red;

           }
       }
    }

    // TODO: tahtadaki x ve o dizilimleri kontrol edilecek ve
    // kazanan varsa x için 1 o için 2 dönecek
    // kazanan yoksa 0 dönecek
    private int checkBoardState()
    {   int result = 0;
        if(playerOrder == 1){

           
            //
            //
            // TODO: Bu bölgeye  O için kazanma kontrolü için gereken kod yazılacak
            //
            //     
        }
        else if(playerOrder == 2){
                //
                //
                // TODO: Bu bölgeye  X için kazanma kontrolü için gereken kod yazılacak
                //
                // 
        }else if(moveCount == 9){
            result = 3;
        } 
        return result;
    }

    private Vector3 KareKonum(int clickedSquare)
    {
        switch (clickedSquare)
        {
            case 0: return new Vector3(-2, 1, -2);
            case 1: return new Vector3(-2, 1,  0);
            case 2: return new Vector3(-2, 1, +2);
            case 3: return new Vector3( 0, 1, -2);
            case 4: return new Vector3( 0, 1,  0);
            case 5: return new Vector3( 0, 1, +2);
            case 6: return new Vector3(+2, 1, -2);
            case 7: return new Vector3(+2, 1,  0);
            case 8: return new Vector3(+2, 1, +2);
            default: throw new Exception("Undefined behaviour");
        }
    }


    private int getClickedSquare ()
    {
        int hitNumber = -1;
        string objectName = "empty";
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out RaycastHit hitInfo))
            { 
                objectName = hitInfo.collider.gameObject.name; 
                switch(objectName){
                    case "Kare1": hitNumber = 0 ; break;
                    case "Kare2": hitNumber = 1 ; break;
                    case "Kare3": hitNumber = 2 ; break;
                    case "Kare4": hitNumber = 3 ; break;
                    case "Kare5": hitNumber = 4 ; break;
                    case "Kare6": hitNumber = 5 ; break;
                    case "Kare7": hitNumber = 6 ; break;
                    case "Kare8": hitNumber = 7 ; break;
                    case "Kare9": hitNumber = 8 ; break;
                }
            }
        }
        
        return hitNumber;
    }


    private bool isSquareEmpty(int squareNumber)
    {
        bool SquareEmpty = false;
        if( squares[squareNumber]==0) SquareEmpty = true;
        return SquareEmpty;
    }

    private Renderer getSquareRenderer(int order)
    {
        string squareName = "Kare"+(order+1);
        GameObject square = GameObject.Find(squareName);
        return square.GetComponent<Renderer>();
    } 


    private Vector3 getSquarePosition(int order)
    {
        string squareName = "Kare"+(order+1);
        GameObject square = GameObject.Find(squareName);
        return  square.transform.position;
    } 


    private Rigidbody getPlayerSignRigidbody(int order){
        string playerSignName = "";
        if(playerOrder == 1){
            playerSignName = "x"+order;
        }else if(playerOrder == 2){
            playerSignName = "o"+order;
        }

        GameObject playerSign = GameObject.Find(playerSignName);
        return playerSign.GetComponent<Rigidbody>();
    }
    
    private void restart()
    { 
    SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    private Vector3 getPlayerSignPosition(int order){
        string playerSignName = "";
        if(playerOrder == 1){
            playerSignName = "x"+order;
        }else if(playerOrder == 2){
            playerSignName = "o"+order;
        }

        GameObject playerSign = GameObject.Find(playerSignName);
        return playerSign.transform.position;
    }


}
